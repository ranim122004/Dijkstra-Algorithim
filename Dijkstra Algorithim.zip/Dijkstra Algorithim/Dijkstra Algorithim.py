def dijkstra(graph, start, goal):
    # Initialize unvisited dictionary with infinite distances for all nodes except the start node
    unvisited = {n: float('inf') for n in graph.keys()}
    unvisited[start] = 0

    # Create dictionaries to store visited nodes and their distances, and reverse path information
    visited = {}
    revPath = {}

    # Main loop until all nodes are visited
    while unvisited:
        # Select the node with the minimum distance as the current node
        minNode = min(unvisited, key=unvisited.get)
        visited[minNode] = unvisited[minNode]

        # If the goal node is reached, exit the loop
        if minNode == goal:
            break

        # Update distances to neighbors of the current node
        for neighbor in graph.get(minNode):
            # Skip neighbors that are already visited
            if neighbor in visited:
                continue

            # Calculate the tentative distance to the neighbor
            tempDist = unvisited[minNode] + graph[minNode][neighbor]

            # Update the distance if it's smaller than the current recorded distance
            if tempDist < unvisited[neighbor]:
                unvisited[neighbor] = tempDist
                revPath[neighbor] = minNode

        # Remove the current node from the unvisited set
        unvisited.pop(minNode)

    # Reconstruct the forward path and return it along with the final distance to the goal node
    node = goal
    revPathString = node

    while node != start:
        revPathString += revPath[node]
        node = revPath[node]

    fwdPath = revPathString[::-1]
    return fwdPath, visited[goal]


if __name__ == '__main__':
    myGraph = {
        'A': {'B': 2, 'C': 9, 'F': 4},
        'B': {'C': 6, 'E': 3, 'F': 2},
        'C': {'D': 1},
        'D': {'C': 2},
        'E': {'D': 5, 'C': 2},
        'F': {'E': 3}
    }

    startNode = 'A'
    goalNode = 'c'
    path, cost = dijkstra(myGraph, startNode, goalNode)

    print(f'The cost to reach from {startNode} to {goalNode} is {cost}.')
    print(f'The path is: {path}')

import random
import datetime
import csv
import os
from tkinter import *
from enum import Enum
from collections import deque

class COLOR(Enum):
    red = 1
    cyan = 2

class maze:
    def __init__(self, rows, cols):
        self.rows = rows
        self.cols = cols
        self.maze_map = {}  # Placeholder for maze_map, replace it with your actual maze structure
        self._goal = (0, 0)  # Set the goal cell (you may adjust this)

    def CreateMaze(self, start_row, start_col, loopPercent):
        # Placeholder for maze creation logic, replace it with your actual maze generation algorithm
        pass

    def tracePath(self, path):
        # Placeholder for tracing the path on the maze, replace it with your actual path tracing logic
        pass

    def run(self):
        # Placeholder for maze simulation logic, replace it with your actual simulation logic
        pass

class agent:
    def __init__(self, maze, row, col, color):
        self.maze = maze
        self.position = (row, col)
        self.color = color
        self.filled = False
        self.footprints = False
        self.cost = 0

def textLabel(maze, label, cost):
    # Placeholder for displaying the label and cost on the maze, replace it with your actual display logic
    pass

def dijkstra(m, *h, start=None):
    # Placeholder for Dijkstra's algorithm implementation
    if start is None:
        start = (m.rows - 1, m.cols - 1)  # Default start position

    # Extract hurdle positions and costs
    hurdles = [(i.position, i.cost) for i in h]

    # Your Dijkstra's algorithm implementation goes here

    # Replace the following with your actual implementation
    fwdPath = {}
    total_cost = 0

    return fwdPath, total_cost

# Main program
if __name__ == '__main__':
    # Create a maze
    myMaze = maze(10, 15)
    myMaze.CreateMaze(1, 4, loopPercent=100)

    # Create hurdle agents
    h1 = agent(myMaze, 4, 4, color=COLOR.red)
    h2 = agent(myMaze, 4, 6, color=COLOR.red)
    h3 = agent(myMaze, 4, 1, color=COLOR.red)
    h4 = agent(myMaze, 4, 2, color=COLOR.red)
    h5 = agent(myMaze, 4, 3, color=COLOR.red)

    # Set hurdle costs
    h1.cost = 100
    h2.cost = 100
    h3.cost = 100
    h4.cost = 100
    h5.cost = 100

    # Run Dijkstra's algorithm and get the path and total cost
    path, c = dijkstra(myMaze, h1, h2, h3, h4, h5, start=(6, 1))

    # Display the total cost on the maze
    textLabel(myMaze, 'Total Cost', c)

    # Create an agent to follow the calculated path
    a = agent(myMaze, 6, 1, color=COLOR.cyan, filled=True, footprints=True)

    # Trace the calculated path on the maze
    myMaze.tracePath({a: path})

    # Run the maze simulation
    myMaze.run()

